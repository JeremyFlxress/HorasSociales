"use client";

import NextFromLogin from "../components/nextfromlogin";

export default function ExamSetupPage() {
  return <NextFromLogin />;
}
