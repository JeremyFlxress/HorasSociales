"use client";

import Agreement from "../components/terminosdeusoTest2";

export default function ExamSetupPage() {
  return <Agreement />;
}
