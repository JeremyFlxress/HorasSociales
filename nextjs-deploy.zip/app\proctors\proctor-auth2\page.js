"use client";

import ProctorAuth from "../components/proctorauth2";

export default function ExamSetupPage() {
  return <ProctorAuth />;
}
