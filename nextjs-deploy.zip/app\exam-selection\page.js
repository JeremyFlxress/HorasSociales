"use client";

import ExamSelection from "../components/examselection";

export default function ExamSetupPage() {
  return <ExamSelection />;
}
