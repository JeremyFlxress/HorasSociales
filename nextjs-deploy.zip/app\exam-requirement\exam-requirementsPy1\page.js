"use client";

import ExamRequirements from "../components/examenrequirementspython1";

export default function ExamSetupPage() {
  return <ExamRequirements />;
}
