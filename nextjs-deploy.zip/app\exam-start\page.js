"use client";

import ExamStart from "../components/exam/ExamStart";

export default function ExamStartPage() {
  return <ExamStart />;
}
