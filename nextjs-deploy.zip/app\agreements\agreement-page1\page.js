"use client";

import Agreement from "../components/terminosdeusoTest1";

export default function ExamSetupPage() {
  return <Agreement />;
}
