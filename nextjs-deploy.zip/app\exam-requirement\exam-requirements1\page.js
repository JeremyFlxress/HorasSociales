"use client";

import ExamRequirements from "../components/examrequirements1";

export default function ExamSetupPage() {
  return <ExamRequirements />;
}
