"use client";

import ProctorAuth from "../components/proctorauth1";

export default function ExamSetupPage() {
  return <ProctorAuth />;
}
