"use client";

import Agreement from "../components/terminosdeusopythonTest1";

export default function ExamSetupPage() {
  return <Agreement />;
}
