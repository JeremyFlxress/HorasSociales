"use client";

import ExamInfo from "../components/examinfopython2";

export default function ExamSetupPage() {
  return <ExamInfo />;
}
