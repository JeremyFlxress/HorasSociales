"use client";

import ProctorAuth from "../components/proctorauthpython1";

export default function ExamSetupPage() {
  return <ProctorAuth />;
}
