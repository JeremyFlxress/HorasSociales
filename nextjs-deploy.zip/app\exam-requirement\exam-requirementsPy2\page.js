"use client";

import ExamRequirements from "../components/examenrequirementspython2";

export default function ExamSetupPage() {
  return <ExamRequirements />;
}
