"use client";

import Agreement from "../components/terminosdeusopythonTest2";

export default function ExamSetupPage() {
  return <Agreement />;
}
