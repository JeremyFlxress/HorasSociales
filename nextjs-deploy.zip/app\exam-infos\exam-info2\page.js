"use client";

import ExamInfo from "../components/examinfo2";

export default function ExamSetupPage() {
  return <ExamInfo />;
}
