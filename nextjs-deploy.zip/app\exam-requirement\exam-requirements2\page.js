"use client";

import ExamRequirements from "../components/examrequirements2";

export default function ExamSetupPage() {
  return <ExamRequirements />;
}
