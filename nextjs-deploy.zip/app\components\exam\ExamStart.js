"use client";

// Move your exam page logic here

export default function ExamStart() {
  return (
    <div className="exam-start-container">
      {/* Add your exam start UI here */}
      <h1>Start Exam</h1>
      {/* Add other exam start content */}
    </div>
  );
}
