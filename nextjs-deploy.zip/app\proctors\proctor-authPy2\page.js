"use client";

import ProctorAuth from "../components/proctorauthpython2";

export default function ExamSetupPage() {
  return <ProctorAuth />;
}
