"use client";

import ExamInfo from "../components/examinfopython1";

export default function ExamSetupPage() {
  return <ExamInfo />;
}
