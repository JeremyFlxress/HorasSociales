"use client";

import ExamInfo from "../components/examinfo1";

export default function ExamSetupPage() {
  return <ExamInfo />;
}
